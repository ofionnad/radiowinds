name = "radiowinds"
from radiowinds import radio_emission
from radiowinds import make_animation
