name = "radiowinds"
version = "0.0.2"
from radiowinds import radio_emission
from radiowinds import make_animation
from radiowinds import test
